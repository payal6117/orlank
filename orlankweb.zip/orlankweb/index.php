<?php require("view/header.php"); ?>



<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>GoodWEB Solutions - Responsive HTML5 Landing Page Template</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    
    <!-- ======================================================= banner Section  1 ===========================================
    ========================================================================================================================   -->

    <section class="banner_section">
        <div class="banner_bg_image     ">
            <div class="banner_item slider-bg">
                <div class="container">
                    <div class="row">
                        <div class="slider-content">
                            <div class="slide-text">
                                <h1 class="compnt_title"> <span> Orlank</span>Technologies  </h1>
                                <h2>With GoodWEB Solutions responsive landing page template, you can promote your all web design & development services. </h2>
                                <div class="marketing_service_btn banner_btn">                                         
                                    <a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ======================================================= free consulting Section 2 ===========================================
    ========================================================================================================================   -->

    <section class="main_section freeConsulting_section ">
        <div class="">
            <h1 class="title">Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet.</h1>
            <div class="card">
                <div class="card_item">
                    <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                    <h1>Completed Projects</h1>
                    <p class="plus_text">500 Plus</p>
                </div>
                <div class="card_item">
                    <i class="fa fa-comments-o " aria-hidden="true"></i>
                    <h1>Completed Projects</h1>
                    <p class="plus_text">500 Plus</p>
                </div>
                <div class="card_item">
                    <i class="fa fa-users" aria-hidden="true"></i>
                    <h1>Completed Projects</h1>
                    <p class="plus_text">500 Plus</p>
                </div>
                <div class="card_item">
                    <i class="fa fa-chrome " aria-hidden="true"></i>
                    <h1>Completed Projects</h1>
                    <p class="plus_text">500 Plus</p>
                </div>

            </div>

            <div class="freeConsulting_content_btn">
                                        
                <a class="button btn btn-light btn-radius btn-brd" href="#">Request A FREE Consulting</a>
            </div>
        </div>
    </section>

    
    <!-- ================================================ Marketing Service Section  ===========================================
    =======================================================================================================================   -->
   
<section class="main_section marketing_service_sec">
    
        <h1 class="title">Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet.</h1>
        <div class="card">
            <div class="item">
                <h1>Lorem</h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsa a enim provident blanditiis necessitatibus nam aliquam voluptas tenetur culpa vitae perspiciatis 
                </p>
                <div class="marketing_service_btn">
                                        
                    <a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>
                </div>
            </div>

            <div class="item">
                <h1>Lorem</h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsa a enim provident blanditiis necessitatibus nam aliquam voluptas tenetur culpa vitae perspiciatis 
                </p>

                <div class="marketing_service_btn">
                                        
                    <a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>
                </div>
            </div>

            <div class="item">
                <h1>Lorem</h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsa a enim provident blanditiis necessitatibus nam aliquam voluptas tenetur culpa vitae perspiciatis 
                </p>

                <div class="marketing_service_btn">
                                        
                    <a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>
                </div>
            </div>

            <div class="item">
                <h1>Lorem</h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsa a enim provident blanditiis necessitatibus nam aliquam voluptas tenetur culpa vitae perspiciatis 
                </p>

                <div class="marketing_service_btn">
                                        
                    <a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>
                </div>
            </div>

        </div>
    </div>
</section>


 <!-- ======================================================= About Section ===========================================
==========================================================================================================================   -->
<section class="main_section about_section">
    <div class="container">
        <div class="content d_grid">
            <div class="item item_left item_left_1 ">
                    <img src="uploads/about_01.jpg" alt="" class="img-responsive img-rounded">
                        <a href="http://www.youtube.com/watch?v=nrJtHemSPW4" 
                           data-rel="prettyPhoto[gal]" class="playbtn">
                           <i class="flaticon-play-button"></i>
                        </a>
            </div>
            
            <div class="item item_right item_right">
                <div class="text_title_box">
                    <h4 class="about_title">About Us</h4>
                    <h2>Welcome to GoodWEB Solutions</h2>
                    <p class="first_p">Quisque eget nisl id nulla sagittis auctor quis id. Aliquam quis vehicula enim, non aliquam risus. Sed a tellus quis mi rhoncus dignissim.</p>

                    <p class="last_p"> Integer rutrum ligula eu dignissim laoreet. Pellentesque venenatis nibh sed tellus faucibus bibendum. Sed fermentum est vitae rhoncus molestie. Cum sociis  </p>

                    <a href="#services" class="btn btn-light btn-radius btn-brd grd1">Learn More</a>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="content d_grid">

            <div class="item item_left  item_left_2">
                <div class="text_title_box">
                    <h4 class="about_title">Who We are</h4>
                    <h2>We Are GoodWEB Solutions</h2>
                    <p class="first_p">Quisque eget nisl id nulla sagittis auctor quis id. Aliquam quis vehicula enim, non aliquam risus. Sed a tellus quis mi rhoncus dignissim.</p>

                    <p class="last_p"> Integer rutrum ligula eu dignissim laoreet. Pellentesque venenatis nibh sed tellus faucibus bibendum. Sed fermentum est vitae rhoncus molestie. Cum sociis
                    </p>
                    <a href="#services" class="btn btn-light btn-radius btn-brd grd1 ">Learn More</a>
                </div>
            </div>
            
            <div class="item item_right">
                    <img src="uploads/about_01.jpg" alt="" class="img-responsive img-rounded">
                    <a href="http://www.youtube.com/watch?v=nrJtHemSPW4" 
                        data-rel="prettyPhoto[gal]" class="playbtn">
                        <i class="flaticon-play-button"></i>
                    </a>
            </div>
            
        </div>
    </div>
</section>


<!-- ======================================================= Happy Client Section ===========================================
    ========================================================================================================================   -->
   
	<section class=" happy_client_section">
        <div class="happy_client_bg_img" data-stellar-background-ratio="0.9" style="background-image:url('uploads/parallax_04.jpg');">
            <div class="container">
                <div class="row text-center content">
                    
                    <div class="col-md-3 col-sm-6 col-xs-12 item ">
                        <span data-scroll class="global-radius icon_bg effect-1"><i class="flaticon-briefcase"></i></span>
                        <p class="stat_count">1200</p>
                        <h3>Complated Projects</h3>
                    </div><!-- end col -->
    
                    <div class="col-md-3 col-sm-6 col-xs-12 item">
                        <span data-scroll class="global-radius icon_bg effect-1"><i class="flaticon-happy"></i></span>
                        <p class="stat_count">3210</p>
                        <h3>Happy Clients</h3>
                    </div><!-- end col -->
    
                    <div class="col-md-3 col-sm-6 col-xs-12 item">
                        <span data-scroll class="global-radius icon_bg effect-1"><i class="flaticon-idea"></i></span>
                        <p class="stat_count">3781</p>
                        <h3>Customer Services</h3>
                    </div><!-- end col -->
    
                    <div class="col-md-3 col-sm-6 col-xs-12 item">
                        <span data-scroll class="global-radius icon_bg effect-1"><i class="flaticon-customer-service"></i></span>
                        <p class="stat_count">4300</p>
                        <h3>Answered Questions</h3>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->    
    </section>



     


  
    <!-- ======================================================= our services section ===========================================
    ========================================================================================================================   -->
   
   <section class="main_section service_section">

         <div class="container">
             <div class="section__title text-center">
                 <h3 class="service_title">Our Service</h3>
                 <p class="lead">Our Service unlimited solutions to all your business needs. in the installation package we prepare search engine optimization, social media support, we provide corporate identity and graphic design services.</p>
             </div>
 
             <div class="owl-services owl-carousel owl-theme">
                 <div class="service-widget">
                     <div class=" wow fadeIn">
                         <a href="uploads/service_01.jpg" data-rel="prettyPhoto[gal]" 
                            class="hoverbutton global-radius">
                            <i class="flaticon-unlink"></i>
                        </a>
                         <img src="uploads/service_01.jpg" alt="" class="img-responsive img-rounded">
                     </div>
                     <div class="service-dit">
                         <h3>Smart Swatch Editions</h3>
                         <p>Aliquam sagittis ligula et sem lacinia, ut facilisis enim sollicitudin. Proin nisi est, convallis nec purus vitae, iaculis posuere sapien. Cum sociis natoque.</p>
                     </div>
                 </div>
                 <!-- end service -->
 
                 <div class="service-widget">
                     <div class="post-media wow fadeIn">
                         <a href="uploads/service_02.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                         <img src="uploads/service_02.jpg" alt="" class="img-responsive img-rounded">
                     </div>
                     <div class="service-dit">
                         <h3>Web UI Kit Design</h3>
                         <p>Duis at tellus at dui tincidunt scelerisque nec sed felis. Suspendisse id dolor sed leo rutrum euismod. Nullam vestibulum fermentum erat. It nam auctor. </p>
                     </div>
                 </div>
                 <!-- end service -->
 
                 <div class="service-widget">
                     <div class="post-media wow fadeIn">
                         <a href="uploads/service_03.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                         <img src="uploads/service_03.jpg" alt="" class="img-responsive img-rounded">
                     </div>
                     <div class="service-dit">
                         <h3>Mobile Optimization</h3>
                         <p>Etiam materials ut mollis tellus, vel posuere nulla. Etiam sit amet lacus vitae massa sodales aliquam at eget quam. Integer ultricies et magna quis accumsan.</p>
                     </div>
                 </div>
                 <!-- end service -->
 
                 <div class="service-widget">
                     <div class="post-media wow fadeIn">
                         <a href="uploads/service_04.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                         <img src="uploads/service_04.jpg" alt="" class="img-responsive img-rounded">
                     </div>
                     <div class="service-dit">
                         <h3>Digital Design for Mac</h3>
                         <p>Praesent in neque congue sapien lobortis faucibus id eget erat. <br>Pellentesque maximus rutrum felis. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
                     </div>
                 </div>
                 <!-- end service -->
             </div><!-- end row -->
 
 
             <div class="text-center">
                 <a data-scroll href="#portfolio" class="btn btn-light btn-radius btn-brd  view_our_portfolio">View Our Portfolio</a>
             </div>
         </div><!-- end container -->
     </div><!-- end section -->

    
    
     

     
    <!-- ======================================================= testimonial section ===========================================
    ========================================================================================================================   -->
    <section class="main_section testimonial__section">
        
        <div class="container">
            <div class="section__title text-center">
                <h3 class="service_title ">Testimonials</h3>
                <p class="lead">Our Service unlimited solutions to all your business needs. in the installation package we prepare search engine optimization, social media support, we provide corporate identity and graphic design services.</p>
            </div>
            
        <div class="testim" id="testim">
            <div class="wrap">

                <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
                <span id="left-arrow" class="arrow left fa fa-chevron-left"></span>

                <ul class="dots" id="testim-dots">
                    <li class="dot active"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                    <li class="dot"></li>
                </ul>

                <div class="cont" id="testim-content">

                    <div class="active">
                        <div class="img"><img src="./img/2.png"></div>
                        <h2 >Lorem N. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quasi aliquid vel voluptatum
                            deleniti! Corrupti velit, porro facere facilis laboriosam accusantium, eos beatae maiores.</p>
                    </div>
                    
                    <div>
                        <div class="img"><img src="./img/2.png"></div>
                        <h2>Lorem L. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quasi aliquid vel voluptatum
                            deleniti! Corrupti velit, porro facere facilis laboriosam accusantium, eos beatae maiores.</p>
                    </div>
                    
                    <div>
                        <div class="img"><img src="./img/2.png"></div>
                        <h2>Lorem R. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quasi aliquid vel voluptatum
                            deleniti! Corrupti velit, porro facere facilis laboriosam accusantium, eos beatae maiores.</p>
                    </div>
                    
                    <div>
                        <div class="img"><img src="./img/2.png"></div>
                        <h2>Lorem P. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quasi aliquid vel voluptatum
                            deleniti! Corrupti velit, porro facere facilis laboriosam accusantium, eos beatae maiores.</p>
                    </div>
                    
                    <div>
                        <div class="img"><img src="./img/2.png"></div>
                        <h2>Lorem Q. Ipsum</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quasi aliquid vel voluptatum
                            deleniti! Corrupti velit, porro facere facilis laboriosam accusantium, eos beatae maiores.</p>
                    </div>
                </div>

            </div>
        </div>
    </div> 
        </div>

        
    <script>
        var testim = document.getElementById("testim"),
        testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
        testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
        testimleftArrow = document.getElementById("left-arrow"),
        testimRightArrow = document.getElementById("right-arrow"),
        testimSpeed = 4500,
        currentSlide = 0,
        currentActive = 0,
        testimTimer
        ;
        // coding with nick
        window.onload = function () {

            // Testim Script
            function playSlide(slide) {
                for (var k = 0; k < testimDots.length; k++) {
                    testimContent[k].classList.remove("active");
                    testimContent[k].classList.remove("inactive");
                    testimDots[k].classList.remove("active");
                }
                if (slide < 0) {
                    slide = currentSlide = testimContent.length - 1;
                }
                if (slide > testimContent.length - 1) {
                    slide = currentSlide = 0;
                }
                if (currentActive != currentSlide) {
                    testimContent[currentActive].classList.add("inactive");
                }
                testimContent[slide].classList.add("active");
                testimDots[slide].classList.add("active");

                currentActive = currentSlide;

                clearTimeout(testimTimer);
                testimTimer = setTimeout(function () {
                    playSlide(currentSlide += 1);
                }, testimSpeed)
            }
            testimleftArrow.addEventListener("click", function () {
                playSlide(currentSlide -= 1);
            })
            testimRightArrow.addEventListener("click", function () {
                playSlide(currentSlide += 1);
            })

            for (var l = 0; l < testimDots.length; l++) {
                testimDots[l].addEventListener("click", function () {
                    playSlide(currentSlide = testimDots.indexOf(this));
                })
            }
            playSlide(currentSlide);

        }
    </script>
    </section>

     <!-- ======================================================= Features section ===========================================
    ========================================================================================================================   -->
    
<div class="main_section feature">
    <div class="container">
        <div class="section-title text-center">
            <h3 class="service_title">Features & Overviews</h3>
            <p class="lead">Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, <br>lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem!</p>
        </div>

        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="features-left">
                    <li class="wow fadeInLeft" id="items" data-wow-duration="1s" data-wow-delay="0.2s">
                        <i class="flaticon-wordpress-logo"></i>
                        <div class="fl-inner">
                            <h4>WordPress Installation</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInLeft" id="items" data-wow-duration="1s" data-wow-delay="0.3s">
                        <i class="flaticon-windows"></i>
                        <div class="fl-inner">
                            <h4>Browser Compatible</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInLeft" id="items" data-wow-duration="1s" data-wow-delay="0.4s">
                        <i class="flaticon-price-tag"></i>
                        <div class="fl-inner">
                            <h4>eCommerce Ready</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInLeft" id="items" data-wow-duration="1s" data-wow-delay="0.5s">
                        <i class="flaticon-new-file"></i>
                        <div class="fl-inner fl_inner_last">
                            <h4>Easy to Customize</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                </ul>
            </div>

            <div class="col-md-4 hidden-xs hidden-sm">
                <img src="uploads/ipad.png" class="img-center img-responsive" alt="">
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="features-right " >
                    <li class="wow fadeInRight" id="items" data-wow-duration="1s" data-wow-delay="0.2s">
                        <i class="flaticon-pantone"></i>
                        <div class="fr-inner">
                            <h4>Limitless Colors</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInRight" id="items" data-wow-duration="1s" data-wow-delay="0.3s">
                        <i class="flaticon-cloud-computing"></i>
                        <div class="fr-inner">
                            <h4>Lifetime Update</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInRight" id="items" data-wow-duration="1s" data-wow-delay="0.4s">
                        <i class="flaticon-line-graph"></i>
                        <div class="fr-inner">
                            <h4>SEO Friendly</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                    <li class="wow fadeInRight" id="items" data-wow-duration="1s" data-wow-delay="0.5s">
                        <i class="flaticon-coding"></i>
                        <div class="fr-inner fr_inner_last ">
                            <h4>Simple Clean Code</h4>
                            <p>Lorem Ipsum dolroin gravida nibh vel velit auctor aliquet. </p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        
     </div>   
</div>
     

    <!-- <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a> -->

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    


<script src="./js/nav.jquery.min.js"></script>
<script>

</script>

<script>
    $('.nav').nav();
</script>



<?php require("view/footer.php"); ?>






