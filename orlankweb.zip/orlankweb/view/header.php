<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="../style.css">
     <!-- Link Swiper's CSS -->
     <link
      rel="stylesheet"
      href="https://unpkg.com/swiper/swiper-bundle.min.css"
    />
</head>
<body>
<header class="top_header_">
            <a href="#" class="nav-button" id="nav-button">Menu</a>
        
            <!-- <div class="logo__">
                <a href="#"><img src="../img/logo.png" alt=""></a>
            </div> -->

            <div class="widget-title logo__">
                <a href="#">
                    <img src="./img/logo.png" alt="" />
                </a>
            </div>
        
            <nav class="nav">
                <ul>
                    <li class="nav-submenu active"  ><a href="#">About Us</a>
                        <ul>
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-submenu" ><a href="#">sub menu3333</a>
                                <ul>
                                    <li><a href="">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                        </ul>
                    </li>
        
        
        
                     <!-- service menu -->
                    <li class="nav-submenu"  id="hover_color" ><a href="#">Services</a>
                        <ul>
                            <li class="nav-submenu" id="submenu_2"><a href="#">sub menu_</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-submenu" id="submenu_2"><a href="#">sub menu__</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                        </ul>
                    </li>
        
        
        
                    <!-- packages menu -->
                    <li class="nav-submenu" id="hover_color"><a href="#">packages</a>
                        <ul>
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                        </ul>
                    </li>
        
        
        
        
                       <!-- Industries menu -->
                       <li class="nav-submenu" id="hover_color"><a href="#">Industries</a>
                        <ul>
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                        </ul>
                    </li>
        
        
        
        
        
                       <!-- blog menu -->
                    <li class="nav-submenu" id="hover_color"><a href="#">Blog</a>
                        <ul class="d-none">
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-submenu" ><a href="#">sub menu</a>
                                <ul>
                                    <li><a href="#">submenu1</a></li>
                        
                                    <li><a href="#">submenu</a></li>
                                </ul>
                            </li>
                            
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                            <li><a href="#">submenu</a></li>
                        </ul>
                    </li>
        
        
                    <li class="nav-submenu" id="hover_color"><a href="#">Contact</a>
                        <ul>
        
                            <li id="contact_width"><a href="#">submenu</a></li>
        
                        </ul>
                    </li>
                </ul>
            </nav>
        
                     
                    <!-- close menu -->
            <a href="#" class="nav-close">Close Menu</a>
        
            
        
        </header>
	</div>


</body>
</html>